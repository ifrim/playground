define(["npm:aurelia-templating@1.0.0-beta.1.1.1/aurelia-templating"], function(main) {
  return main;
});