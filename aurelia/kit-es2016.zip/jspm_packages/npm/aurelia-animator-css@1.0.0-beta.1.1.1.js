define(["npm:aurelia-animator-css@1.0.0-beta.1.1.1/aurelia-animator-css"], function(main) {
  return main;
});