/* */ 
module.exports = require('./selfGlobal');
