/* */ 
module.exports = { "default": require("core-js/library/fn/date/add-locale"), __esModule: true };