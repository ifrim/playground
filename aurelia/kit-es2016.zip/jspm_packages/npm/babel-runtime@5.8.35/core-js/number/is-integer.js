/* */ 
module.exports = { "default": require("core-js/library/fn/number/is-integer"), __esModule: true };