/* */ 
module.exports = { "default": require("core-js/library/fn/math/cosh"), __esModule: true };