/* */ 
module.exports = { "default": require("core-js/library/fn/math/log2"), __esModule: true };