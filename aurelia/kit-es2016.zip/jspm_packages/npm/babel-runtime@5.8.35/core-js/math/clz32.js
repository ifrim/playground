/* */ 
module.exports = { "default": require("core-js/library/fn/math/clz32"), __esModule: true };