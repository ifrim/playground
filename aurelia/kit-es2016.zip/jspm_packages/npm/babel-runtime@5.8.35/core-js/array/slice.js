/* */ 
module.exports = { "default": require("core-js/library/fn/array/slice"), __esModule: true };