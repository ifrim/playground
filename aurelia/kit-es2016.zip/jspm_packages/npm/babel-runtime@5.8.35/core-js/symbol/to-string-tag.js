/* */ 
module.exports = { "default": require("core-js/library/fn/symbol/to-string-tag"), __esModule: true };