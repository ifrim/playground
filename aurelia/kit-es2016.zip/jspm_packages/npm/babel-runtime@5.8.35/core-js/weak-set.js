/* */ 
module.exports = { "default": require("core-js/library/fn/weak-set"), __esModule: true };