define(["npm:aurelia-pal-browser@1.0.0-beta.1.1.3/aurelia-pal-browser"], function(main) {
  return main;
});