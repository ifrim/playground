define(["npm:aurelia-pal@1.0.0-beta.1.1.1/aurelia-pal"], function(main) {
  return main;
});