define(["github:components/jquery@2.2.0/jquery"], function(main) {
  return main;
});