jQuery Component
================

Shim [repository](https://github.com/components/jquery) for the [jQuery](http://jquery.com).

Package Managers
----------------

* [Bower](http://bower.io/): `jquery`
* [Component](https://github.com/component/component): `components/jquery`
* [Composer](http://packagist.org/packages/components/jquery): `components/jquery`
* [spm](http://spmjs.io/package/jquery): `jquery`
